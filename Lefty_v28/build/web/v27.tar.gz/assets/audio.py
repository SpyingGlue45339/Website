from pathlib import Path
import random
import pygame


# ============================================================
# LEFTY AUDIO SYSTEM
# ============================================================

AUDIO_DIR = Path(__file__).resolve().parent / "photos" / "audio"

BACKGROUND = AUDIO_DIR / "background.mp3"

# Supported audio formats that Pygame can load directly.
SUPPORTED_AUDIO = {".mp3", ".wav", ".ogg"}


# ============================================================
# PROBABILITIES
# ============================================================
#
# Every interactive sound trigger is divided into:
#
#   Voice lines  = 15%
#   Button       = 60%
#   Newspaper    = 25%
#
# Total = 100%
#
# If one category is empty, its probability is redistributed
# automatically between the categories that actually exist.
#

AUDIO_GROUPS = (
    ("voice lines", 0.15),
    ("button", 0.60),
    ("newspaper", 0.25),
)


# ============================================================
# INTERNAL STATE
# ============================================================

_ready = False

# Sound cache:
# {Path: pygame.mixer.Sound}
_cache = {}

# Voice-line shuffled bag.
# A voice line is not repeated until every voice line has been used.
_voice_line_bag = []

# Dedicated channels.
_sfx_channel = None
_voice_channel = None


# ============================================================
# INITIALISATION
# ============================================================

def initialise():
    """
    Initialise the Pygame mixer and start the background music.

    Audio is deliberately non-fatal:
    if the mixer cannot initialise, the game continues without sound.
    """

    global _ready
    global _sfx_channel
    global _voice_channel

    try:
        if not pygame.mixer.get_init():
            pygame.mixer.init(
                frequency=44100,
                size=-16,
                channels=2,
                buffer=512,
            )

        # Make sure we have enough mixer channels.
        pygame.mixer.set_num_channels(8)

        # Channel 1 = ordinary sound effects.
        _sfx_channel = pygame.mixer.Channel(1)

        # Channel 2 = voice lines.
        _voice_channel = pygame.mixer.Channel(2)

        _ready = True

        print("[Lefty audio] Mixer initialised.")

        _report_audio_inventory()

        play_background()

    except (pygame.error, OSError) as exc:
        _ready = False
        print(f"[Lefty audio] Mixer could not initialise: {exc}")


# ============================================================
# BACKGROUND MUSIC
# ============================================================

def play_background():
    """
    Start looping background music.
    """

    if not _ready:
        return

    if not BACKGROUND.exists():
        print(
            f"[Lefty audio] Background music not found: "
            f"{BACKGROUND}"
        )
        return

    try:
        pygame.mixer.music.load(str(BACKGROUND))
        pygame.mixer.music.set_volume(0.45)
        pygame.mixer.music.play(-1)

        print(
            f"[Lefty audio] Background music playing: "
            f"{BACKGROUND.name}"
        )

    except (pygame.error, OSError) as exc:
        print(
            f"[Lefty audio] Could not play background music "
            f"{BACKGROUND.name}: {exc}"
        )


def stop_background():
    """
    Stop background music.
    """

    if not _ready:
        return

    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass


def set_background_volume(volume):
    """
    Set background music volume.
    """

    if not _ready:
        return

    volume = max(0.0, min(1.0, float(volume)))

    try:
        pygame.mixer.music.set_volume(volume)
    except pygame.error:
        pass


# ============================================================
# FILE DISCOVERY
# ============================================================

def _files_in(folder_name):
    """
    Return all directly playable audio files in a category folder.
    """

    folder = AUDIO_DIR / folder_name

    if not folder.exists():
        return []

    if not folder.is_dir():
        return []

    files = []

    try:
        for path in folder.iterdir():

            if not path.is_file():
                continue

            if path.suffix.lower() not in SUPPORTED_AUDIO:
                continue

            files.append(path)

    except OSError as exc:
        print(
            f"[Lefty audio] Could not read folder "
            f"{folder}: {exc}"
        )
        return []

    return sorted(
        files,
        key=lambda p: p.name.lower()
    )


# ============================================================
# AUDIO INVENTORY / DIAGNOSTICS
# ============================================================

def _report_audio_inventory():
    """
    Print exactly what audio files the game can see.

    This is particularly useful for diagnosing the voice-line issue.
    """

    if not _ready:
        return

    print()
    print("[Lefty audio] ===============================")
    print("[Lefty audio] AUDIO INVENTORY")
    print("[Lefty audio] ===============================")

    total = 0

    for name, _weight in AUDIO_GROUPS:

        files = _files_in(name)

        print(
            f"[Lefty audio] {name}: {len(files)} file(s)"
        )

        for path in files:
            print(
                f"[Lefty audio]     - {path.name}"
            )

        total += len(files)

    print(
        f"[Lefty audio] Total interactive files: {total}"
    )

    voice_files = _files_in("voice lines")

    if voice_files:
        print(
            f"[Lefty audio] VOICE LINES AVAILABLE: "
            f"{len(voice_files)}"
        )
        print(
            "[Lefty audio] Voice-line probability: 15%"
        )
    else:
        print(
            "[Lefty audio] WARNING: NO VOICE LINES FOUND."
        )
        print(
            "[Lefty audio] Expected folder:"
        )
        print(
            f"[Lefty audio]     {AUDIO_DIR / 'voice lines'}"
        )

    print("[Lefty audio] ===============================")
    print()


# ============================================================
# VOICE-LINE BAG
# ============================================================

def _next_voice_line():
    """
    Return the next voice line from a shuffled no-repeat bag.

    Every voice line is used once before the bag is refilled.
    """

    global _voice_line_bag

    files = _files_in("voice lines")

    if not files:
        return None

    # Remove files from the bag that no longer exist.
    current_files = set(files)

    _voice_line_bag = [
        path
        for path in _voice_line_bag
        if path in current_files
    ]

    # Refill the bag when empty.
    if not _voice_line_bag:

        _voice_line_bag = files[:]

        random.shuffle(_voice_line_bag)

    return _voice_line_bag[-1]


def _consume_voice_line(path):
    """
    Remove a successfully played voice line from the bag.
    """

    global _voice_line_bag

    if path in _voice_line_bag:
        _voice_line_bag.remove(path)


# ============================================================
# SOUND LOADING
# ============================================================

def _load_sound(path):
    """
    Load a sound into the cache.

    Returns:
        pygame.mixer.Sound
        or None if loading failed.
    """

    if path is None:
        return None

    if not path.exists():
        print(
            f"[Lefty audio] File does not exist: {path}"
        )
        return None

    if path in _cache:
        return _cache[path]

    try:

        sound = pygame.mixer.Sound(str(path))

        _cache[path] = sound

        return sound

    except (pygame.error, OSError) as exc:

        print()
        print(
            f"[Lefty audio] FAILED TO LOAD AUDIO:"
        )
        print(
            f"[Lefty audio]     {path.name}"
        )
        print(
            f"[Lefty audio]     {exc}"
        )
        print()

        return None


# ============================================================
# PLAYING ORDINARY SOUND EFFECTS
# ============================================================

def _play_sfx(path, volume=0.80):
    """
    Play an ordinary sound effect on the dedicated SFX channel.
    """

    if path is None:
        return False

    if not _ready:
        return False

    sound = _load_sound(path)

    if sound is None:
        return False

    try:

        volume = max(
            0.0,
            min(1.0, float(volume))
        )

        sound.set_volume(volume)

        if _sfx_channel is not None:
            _sfx_channel.play(sound)
        else:
            sound.play()

        return True

    except (pygame.error, OSError) as exc:

        print(
            f"[Lefty audio] Failed playing "
            f"{path.name}: {exc}"
        )

        return False


# ============================================================
# PLAYING VOICE LINES
# ============================================================

def _play_voice_line(path, volume=1.0):
    """
    Play a voice line on its own dedicated mixer channel.

    Voice lines deliberately have their own channel so that they
    are not fighting ordinary button/newspaper sounds.
    """

    if path is None:
        return False

    if not _ready:
        return False

    sound = _load_sound(path)

    if sound is None:
        return False

    try:

        volume = max(
            0.0,
            min(1.0, float(volume))
        )

        sound.set_volume(volume)

        if _voice_channel is not None:
            _voice_channel.play(sound)
        else:
            sound.play()

        print(
            f"[Lefty audio] PLAYING VOICE LINE: "
            f"{path.name}"
        )

        return True

    except (pygame.error, OSError) as exc:

        print(
            f"[Lefty audio] FAILED TO PLAY VOICE LINE:"
        )
        print(
            f"[Lefty audio]     {path.name}"
        )
        print(
            f"[Lefty audio]     {exc}"
        )

        return False


# ============================================================
# CATEGORY HELPERS
# ============================================================

def _populated_groups():
    """
    Return only categories containing playable audio files.
    """

    populated = []

    for name, _weight in AUDIO_GROUPS:

        files = _files_in(name)

        if files:
            populated.append(
                (name, files)
            )

    return populated


# ============================================================
# RANDOM INTERACTIVE SOUND
# ============================================================

def play_random_sound():
    """
    Play one random interactive sound.

    Intended probabilities:

        Voice lines = 15%
        Button      = 60%
        Newspaper   = 25%

    If a category does not exist, its probability is automatically
    redistributed amongst the categories that do exist.

    Voice lines use a shuffled no-repeat bag.
    """

    if not _ready:
        return False

    populated = _populated_groups()

    if not populated:
        print(
            "[Lefty audio] No interactive audio files available."
        )
        return False

    # --------------------------------------------------------
    # Build the weighted choice using only populated groups.
    # --------------------------------------------------------

    weight_lookup = dict(AUDIO_GROUPS)

    available_names = [
        name
        for name, _files in populated
    ]

    available_weights = [
        weight_lookup[name]
        for name in available_names
    ]

    chosen = random.choices(
        available_names,
        weights=available_weights,
        k=1,
    )[0]

    print(
        f"[Lefty audio] Selected category: {chosen}"
    )

    # --------------------------------------------------------
    # VOICE LINE
    # --------------------------------------------------------

    if chosen == "voice lines":

        files = _files_in("voice lines")

        if not files:
            print(
                "[Lefty audio] Voice category selected, "
                "but no voice files exist."
            )
            return False

        # Try the shuffled bag first.
        voice_path = _next_voice_line()

        if voice_path is not None:

            if _play_voice_line(
                voice_path,
                volume=1.0
            ):

                _consume_voice_line(
                    voice_path
                )

                return True

            # If that particular file failed to load,
            # try the other voice files rather than giving up.
            remaining = [
                path
                for path in files
                if path != voice_path
            ]

            random.shuffle(remaining)

            for path in remaining:

                if _play_voice_line(
                    path,
                    volume=1.0
                ):

                    _consume_voice_line(
                        path
                    )

                    return True

        print(
            "[Lefty audio] Every voice line failed to play."
        )

        return False

    # --------------------------------------------------------
    # BUTTON / NEWSPAPER
    # --------------------------------------------------------

    files = _files_in(chosen)

    if not files:
        print(
            f"[Lefty audio] Selected category "
            f"'{chosen}' has no files."
        )
        return False

    # Try random files until one works.
    candidates = files[:]
    random.shuffle(candidates)

    for path in candidates:

        if _play_sfx(
            path,
            volume=0.80
        ):
            print(
                f"[Lefty audio] Playing {chosen}: "
                f"{path.name}"
            )
            return True

    print(
        f"[Lefty audio] Every file in "
        f"'{chosen}' failed to play."
    )

    return False


# ============================================================
# BACKWARDS COMPATIBILITY
# ============================================================

# If the rest of your game already calls this old function name,
# it will continue to work.

play_random_noise = play_random_sound